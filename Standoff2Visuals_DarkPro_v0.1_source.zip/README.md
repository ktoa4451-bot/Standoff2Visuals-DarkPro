# Standoff 2 Visuals — Dark Pro (Android source)

A standalone Android Studio prototype for a customizable visual-settings panel.
It does **not** modify Standoff 2, inject into it, or claim to change the game's rendering.
The crosshair is preview-only; weapon cards are illustrative placeholders.

## Build
1. Open this folder in Android Studio (recent version).
2. Let Gradle sync.
3. Build > Build APK(s).

Requires Android Studio with Android Gradle Plugin support and JDK 17.
If your local Android Studio suggests a newer compatible Gradle/AGP version, use its upgrade prompt.

## Prototype features
- Dark Pro interface
- Crosshair preview and preset selector
- Accent color themes
- Brightness and contrast preview sliders
- Animation toggle
- Weapon/skin showcase cards (illustrative, not game assets)
- Navigation between Visuals, Arsenal, and Settings

## Project status
Version 0.1 — source scaffold. No game integration is included.
