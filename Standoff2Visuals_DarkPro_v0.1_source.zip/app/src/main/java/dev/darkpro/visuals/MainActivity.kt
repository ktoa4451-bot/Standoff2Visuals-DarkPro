package dev.darkpro.visuals

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Bg = Color(0xFF090B10)
private val Panel = Color(0xFF141821)
private val Panel2 = Color(0xFF1C2230)
private val TextMain = Color(0xFFF2F5FA)
private val TextMuted = Color(0xFF8F9BAD)
private val Accents = listOf(Color(0xFF55D6FF), Color(0xFF9B7BFF), Color(0xFF54E0A3), Color(0xFFFFB454))

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { DarkProApp() }
    }
}

@Composable
private fun DarkProApp() {
    var page by remember { mutableStateOf("Visuals") }
    var accentIndex by remember { mutableIntStateOf(0) }
    var crosshair by remember { mutableStateOf("Classic") }
    var animations by remember { mutableStateOf(true) }
    var brightness by remember { mutableFloatStateOf(0.5f) }
    var contrast by remember { mutableFloatStateOf(0.6f) }
    val accent = Accents[accentIndex]

    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = accent,
            background = Bg,
            surface = Panel,
            onBackground = TextMain,
            onSurface = TextMain
        )
    ) {
        Column(
            Modifier.fillMaxSize().background(Bg).padding(horizontal = 18.dp)
        ) {
            Spacer(Modifier.height(22.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier.size(42.dp).background(accent.copy(alpha = .16f), RoundedCornerShape(14.dp))
                        .border(1.dp, accent.copy(alpha = .55f), RoundedCornerShape(14.dp)),
                    contentAlignment = Alignment.Center
                ) { Text("DP", color = accent, fontWeight = FontWeight.Black, fontSize = 17.sp) }
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text("DARK PRO", fontSize = 21.sp, fontWeight = FontWeight.Black, color = TextMain)
                    Text("VISUAL CONTROL • v0.1", fontSize = 10.sp, color = TextMuted, letterSpacing = 1.4.sp)
                }
                Box(Modifier.size(8.dp).background(Color(0xFF54E0A3), CircleShape))
            }
            Spacer(Modifier.height(20.dp))
            Row(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(16.dp)).padding(5.dp)) {
                listOf("Visuals", "Arsenal", "Settings").forEach { item ->
                    Box(
                        Modifier.weight(1f).background(
                            if (page == item) accent.copy(alpha = .17f) else Color.Transparent,
                            RoundedCornerShape(12.dp)
                        ).clickable { page = item }.padding(vertical = 12.dp),
                        contentAlignment = Alignment.Center
                    ) { Text(item, color = if (page == item) accent else TextMuted, fontWeight = FontWeight.SemiBold, fontSize = 12.sp) }
                }
            }
            Spacer(Modifier.height(16.dp))
            AnimatedVisibility(visible = true, enter = fadeIn(), exit = fadeOut()) {
                when (page) {
                    "Visuals" -> VisualsPage(accent, crosshair, { crosshair = it }, brightness, { brightness = it }, contrast, { contrast = it })
                    "Arsenal" -> ArsenalPage(accent)
                    else -> SettingsPage(accent, accentIndex, { accentIndex = it }, animations, { animations = it })
                }
            }
        }
    }
}

@Composable
private fun VisualsPage(
    accent: Color, crosshair: String, onCrosshair: (String) -> Unit,
    brightness: Float, onBrightness: (Float) -> Unit,
    contrast: Float, onContrast: (Float) -> Unit
) {
    LazyColumn(verticalArrangement = Arrangement.spacedBy(14.dp), contentPadding = PaddingValues(bottom = 24.dp)) {
        item {
            Column(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(20.dp)).padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("CROSSHAIR LAB", fontSize = 12.sp, color = TextMuted, letterSpacing = 1.3.sp)
                        Text("Preview studio", fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    }
                    Text("PREVIEW", color = accent, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                }
                Spacer(Modifier.height(14.dp))
                Box(Modifier.fillMaxWidth().height(176.dp).background(Color(0xFF10151C), RoundedCornerShape(14.dp)), contentAlignment = Alignment.Center) {
                    Canvas(Modifier.size(120.dp)) {
                        val c = accent
                        val center = Offset(size.width / 2, size.height / 2)
                        val stroke = 3.5f
                        when (crosshair) {
                            "Dot" -> drawCircle(c, radius = 4.5f, center = center)
                            "Circle" -> drawCircle(c, radius = 20f, center = center, style = androidx.compose.ui.graphics.drawscope.Stroke(strokeWidth = stroke))
                            "Classic" -> {
                                drawLine(c, Offset(center.x - 25, center.y), Offset(center.x - 8, center.y), stroke, cap = StrokeCap.Round)
                                drawLine(c, Offset(center.x + 8, center.y), Offset(center.x + 25, center.y), stroke, cap = StrokeCap.Round)
                                drawLine(c, Offset(center.x, center.y - 25), Offset(center.x, center.y - 8), stroke, cap = StrokeCap.Round)
                                drawLine(c, Offset(center.x, center.y + 8), Offset(center.x, center.y + 25), stroke, cap = StrokeCap.Round)
                                drawCircle(c, radius = 2.5f, center = center)
                            }
                            else -> {
                                drawLine(c, Offset(center.x - 24, center.y - 24), Offset(center.x - 9, center.y - 9), stroke)
                                drawLine(c, Offset(center.x + 24, center.y - 24), Offset(center.x + 9, center.y - 9), stroke)
                                drawLine(c, Offset(center.x - 24, center.y + 24), Offset(center.x - 9, center.y + 9), stroke)
                                drawLine(c, Offset(center.x + 24, center.y + 24), Offset(center.x + 9, center.y + 9), stroke)
                            }
                        }
                    }
                }
                Spacer(Modifier.height(14.dp))
                Text("STYLE", fontSize = 10.sp, color = TextMuted, letterSpacing = 1.2.sp)
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("Classic", "Dot", "Circle", "X").forEach { name ->
                        Box(
                            Modifier.weight(1f).background(if (crosshair == name) accent.copy(alpha = .18f) else Panel2, RoundedCornerShape(10.dp))
                                .border(1.dp, if (crosshair == name) accent else Color.Transparent, RoundedCornerShape(10.dp))
                                .clickable { onCrosshair(name) }.padding(vertical = 11.dp),
                            contentAlignment = Alignment.Center
                        ) { Text(name, fontSize = 11.sp, color = if (crosshair == name) accent else TextMain) }
                    }
                }
            }
        }
        item {
            Column(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(20.dp)).padding(16.dp)) {
                Text("DISPLAY TUNING", fontSize = 12.sp, color = TextMuted, letterSpacing = 1.3.sp)
                Spacer(Modifier.height(10.dp))
                Text("Brightness  ${(brightness * 100).toInt()}%", fontWeight = FontWeight.SemiBold)
                Slider(value = brightness, onValueChange = onBrightness, colors = SliderDefaults.colors(thumbColor = accent, activeTrackColor = accent))
                Text("Contrast  ${(contrast * 100).toInt()}%", fontWeight = FontWeight.SemiBold)
                Slider(value = contrast, onValueChange = onContrast, colors = SliderDefaults.colors(thumbColor = accent, activeTrackColor = accent))
                Text("Эти значения пока служат настройками предпросмотра приложения.", fontSize = 11.sp, color = TextMuted)
            }
        }
        item { Text("Standalone preview • No game connection", color = TextMuted, fontSize = 10.sp) }
    }
}

@Composable
private fun ArsenalPage(accent: Color) {
    LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp), contentPadding = PaddingValues(bottom = 24.dp)) {
        item {
            Text("ARSENAL SHOWCASE", fontSize = 12.sp, color = TextMuted, letterSpacing = 1.3.sp)
            Text("Weapon & skin concepts", fontSize = 22.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(5.dp))
            Text("Иллюстративные карточки — не игровые модели и не реальные игровые предметы.", color = TextMuted, fontSize = 11.sp)
        }
        items(4) { index ->
            val names = listOf("PHANTOM / CYAN EDGE", "VORTEX / NIGHT GRID", "SPECTRE / AMETHYST", "TITAN / EMERALD CORE")
            val shades = listOf(Color(0xFF163E4A), Color(0xFF303443), Color(0xFF35224B), Color(0xFF173D32))
            Row(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(18.dp)).padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(86.dp, 68.dp).background(shades[index], RoundedCornerShape(12.dp)), contentAlignment = Alignment.Center) {
                    Canvas(Modifier.fillMaxSize().padding(10.dp)) {
                        val y = size.height / 2
                        drawLine(accent, Offset(4f, y), Offset(size.width - 4f, y), 8f, cap = StrokeCap.Round)
                        drawLine(Color.White.copy(alpha = .7f), Offset(size.width * .28f, y - 10), Offset(size.width * .65f, y - 10), 3f, cap = StrokeCap.Round)
                        drawCircle(accent, 4f, Offset(size.width * .72f, y))
                    }
                }
                Spacer(Modifier.width(14.dp))
                Column(Modifier.weight(1f)) {
                    Text(names[index], fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(5.dp))
                    Text("CONCEPT SKIN", color = accent, fontSize = 10.sp, letterSpacing = 1.sp)
                    Text("Preview item ${index + 1}", color = TextMuted, fontSize = 11.sp)
                }
            }
        }
    }
}

@Composable
private fun SettingsPage(accent: Color, selected: Int, onSelected: (Int) -> Unit, animations: Boolean, onAnimations: (Boolean) -> Unit) {
    LazyColumn(verticalArrangement = Arrangement.spacedBy(14.dp), contentPadding = PaddingValues(bottom = 24.dp)) {
        item {
            Column(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(20.dp)).padding(16.dp)) {
                Text("COLOR THEMES", fontSize = 12.sp, color = TextMuted, letterSpacing = 1.3.sp)
                Spacer(Modifier.height(14.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                    Accents.forEachIndexed { index, color ->
                        Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.clickable { onSelected(index) }) {
                            Box(Modifier.size(42.dp).background(color, CircleShape).then(if (selected == index) Modifier.border(3.dp, TextMain, CircleShape) else Modifier))
                            Spacer(Modifier.height(6.dp))
                            Text(listOf("Ice", "Violet", "Mint", "Amber")[index], fontSize = 10.sp, color = if (selected == index) TextMain else TextMuted)
                        }
                    }
                }
            }
        }
        item {
            Row(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(20.dp)).padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("UI animations", fontWeight = FontWeight.Bold)
                    Text("Animated transitions inside this app", color = TextMuted, fontSize = 11.sp)
                }
                Switch(checked = animations, onCheckedChange = onAnimations, colors = SwitchDefaults.colors(checkedThumbColor = accent, checkedTrackColor = accent.copy(alpha = .4f)))
            }
        }
        item {
            Column(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(20.dp)).padding(16.dp)) {
                Text("ABOUT", fontSize = 12.sp, color = TextMuted, letterSpacing = 1.3.sp)
                Spacer(Modifier.height(8.dp))
                Text("Dark Pro Visuals • 0.1", fontWeight = FontWeight.Bold)
                Text("Самостоятельный прототип. Не связан с разработчиками Standoff 2.", color = TextMuted, fontSize = 12.sp)
            }
        }
    }
}
